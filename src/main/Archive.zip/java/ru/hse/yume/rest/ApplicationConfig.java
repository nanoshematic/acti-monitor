package ru.hse.yume.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Author: Alexey Batrakov
 * Date: 11/04/17.
 */
@ApplicationPath("rest") // set the path to REST web services
public class ApplicationConfig extends Application {
}