package ru.hse.yume.data.dao;

import ru.hse.yume.data.entity.ActivityInstance;
import ru.hse.yume.data.entity.ActivityInstanceCount;
import ru.hse.yume.data.entity.Process;

import java.io.IOException;
import java.util.List;

/**
 * Author: Alexey Batrakov
 * Date: 13/04/17.
 */
public interface IProcessDefinitionDao {

    public String getProcessDiagramXml(String key, int version) throws IOException;

    public int getLatestVersionForProcessDefinition(String key) throws IOException;

    List<Process> getProcessList() throws IOException;

    List<ActivityInstance> getCurrentActivities(String processDefId) throws IOException;

    List<ActivityInstanceCount> getCurrentActivitiesCount(String key, String version) throws IOException;

    List<ActivityInstanceCount> getActivitiesCount(String key) throws IOException;
}
