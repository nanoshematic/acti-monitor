package ru.hse.yume.data.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import ru.hse.yume.data.entity.*;
import ru.hse.yume.data.entity.Process;

import java.util.List;

/**
 * Author: Alexey Batrakov
 * Date: 13/04/17.
 */
public interface ProcessDefinitionMapper {
    @Select("SELECT * FROM act_re_procdef WHERE key_ = #{key} AND version_ = #{version}")
    ProcessDefinition getProcessDefinitionByKeyAndVersion(@Param("key") String key, @Param("version") Integer version);

    @Select("SELECT bytes_ FROM act_ge_bytearray WHERE name_ = #{name} AND deployment_id_ = #{deployment_id}")
    Object getXmlDiagramResource(@Param("name") String name, @Param("deployment_id") String deploymentId);

    @Select("SELECT MAX(version_) FROM act_re_procdef WHERE key_ = #{key}")
    Integer getLatestVersion(@Param("key") String key);

    @Select("SELECT DISTINCT name_, key_ FROM act_re_procdef")
    List<Process> getProcessList();

    @Select("SELECT * FROM activiti.act_hi_actinst WHERE end_time_ IS NULL AND proc_def_id_ =  #{proc_def_id}")
    List<ActivityInstance> getCurrentActivities(@Param("proc_def_id") String key);

    @Select("SELECT count(*), act_id_ FROM activiti.act_hi_actinst WHERE end_time_ IS NULL AND proc_def_id_ LIKE #{proc_def_id} GROUP BY act_id_")
    List<ActivityInstanceCount> getCurrentActivitiesCount(@Param("proc_def_id") String procDefIdLike);

    @Select("SELECT count(*), act_id_ FROM activiti.act_hi_actinst WHERE proc_def_id_ LIKE #{proc_def_id} GROUP BY act_id_")
    List<ActivityInstanceCount> getActivitiesCount(@Param("proc_def_id") String procDefIdLike);

    @Select("SELECT\n" +
            "  count(*),\n" +
            "  act_id_\n" +
            "FROM activiti.act_hi_actinst act LEFT JOIN activiti.act_hi_taskinst task ON act.task_id_ = task.id_\n" +
            "WHERE task.end_time_ > task.due_date_ AND act.proc_def_id_ LIKE #{proc_def_id}\n" +
            "GROUP BY act_id_")
    List<ActivityInstanceCount> getCurrentActivitiesOverdueCount(@Param("proc_def_id") String procDefIdLike);

    @Select("SELECT * FROM activiti.act_re_procdef WHERE key_ = #{key}")
    List<ProcessDefinition> getAllDefinitionsByKey(@Param("key") String key);

    @Select()
    List<TaskDuration> getAvgTaskDurationByAsignee;

}
