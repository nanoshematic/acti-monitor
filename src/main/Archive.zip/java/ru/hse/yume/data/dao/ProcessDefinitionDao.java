package ru.hse.yume.data.dao;

import org.apache.ibatis.session.SqlSession;
import ru.hse.yume.data.entity.ActivityInstance;
import ru.hse.yume.data.entity.ActivityInstanceCount;
import ru.hse.yume.data.entity.Process;
import ru.hse.yume.data.entity.ProcessDefinition;
import ru.hse.yume.data.mapper.ProcessDefinitionMapper;

import java.io.IOException;
import java.util.List;

/**
 * Author: Alexey Batrakov
 * Date: 13/04/17.
 */
public class ProcessDefinitionDao implements IProcessDefinitionDao {

    @Override
    public String getProcessDiagramXml(String key, int version) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            ProcessDefinition definition = mapper.getProcessDefinitionByKeyAndVersion(key, version);
            Object xml = mapper.getXmlDiagramResource(definition.getResourceName(), definition.getDeploymentId());

            String res = new String((byte[]) xml, "UTF-8");
            // ToDo: analyse subprocesses, mark is expanded
            res = res.replace("<bpmndi:BPMNShape bpmnElement=\"subprocess1\" id=\"BPMNShape_subprocess1\">",
                    "<bpmndi:BPMNShape bpmnElement=\"subprocess1\" id=\"BPMNShape_subprocess1\" isExpanded=\"true\">");
            return res;
        }
    }

    @Override
    public int getLatestVersionForProcessDefinition(String key) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            return mapper.getLatestVersion(key);
        }
    }

    @Override
    public List<Process> getProcessList() throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            return mapper.getProcessList();
        }
    }

    @Override
    public List<ActivityInstance> getCurrentActivities(String processDefId) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            return mapper.getCurrentActivities(processDefId);
        }
    }

    @Override
    public List<ActivityInstanceCount> getCurrentActivitiesCount(String key, String version) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            String like = key;
            if (version != null) {
                like += ":" + version;
            }
            return mapper.getCurrentActivitiesCount(like + "%");
        }
    }

    @Override
    public List<ActivityInstanceCount> getActivitiesCount(String key) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            return mapper.getActivitiesCount(key + "%");
        }
    }

    public List<ProcessDefinition> getAllDefinitionsByKey(String key) throws IOException {
        try (SqlSession session = AbstractDao.getSessionFactory().openSession()) {
            ProcessDefinitionMapper mapper = session.getMapper(ProcessDefinitionMapper.class);
            return mapper.getAllDefinitionsByKey(key);
        }
    }
}
