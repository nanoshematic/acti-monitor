package ru.hse.yume.data.entity;

/**
 * Author: Alexey Batrakov
 * Date: 16/04/17.
 */
public class Process {
    private String key;

    private String name;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
