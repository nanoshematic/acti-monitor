package ru.hse.yume.data.entity;

/**
 * Author: Alexey Batrakov
 * Date: 11/04/17.
 */
public class ActivityInstanceCount {
    private String actId;

    private Integer count;

    public String getActId() {
        return actId;
    }

    public void setActId(String actId) {
        this.actId = actId;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
