angular.module('activitiMonitor.dashboard', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/dashboard', {
            templateUrl: 'dashboard/dashboard.html',
            controller: 'DashboardCtrl'
        });
    }])

    .controller('DashboardCtrl', function($scope, $http, $routeParams, $location) {
        $http({
            method: 'GET',
            url: '/monitor/rest/process-definition/all'
        }).then(function successCallback(response) {
            $scope.processes = response.data;
            console.log(response.data)
        }, function errorCallback(response) {
            console.log(response.data);
            // called asynchronously if an error occurs
            // or server returns response with an error status.
        });

        $scope.setSelected = function () {
            $scope.selected = this.process;
            $location.path('procdef/' + $scope.selected.key);
            // console.log($scope.selected);
            // createDiagram($scope.selected.key);
        };
        console.log('3');
        console.log($routeParams);
    });